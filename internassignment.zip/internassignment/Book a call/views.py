from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def home(request):
    return render(request, 'Home.html')

def Add_Advisor(request):
    return render(request, 'Add_Advisor.html')

def Add_User(request):
    return render(request, 'Add_User.html')
