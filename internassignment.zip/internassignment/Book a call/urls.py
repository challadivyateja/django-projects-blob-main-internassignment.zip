from django.urls import path,include

from . import views

urlpatterns = [
    path('/admin', views.home, name = 'home'),
    path('/admin/Add_advisor', include('Add_advisor.urls')),
    path('/admin/Add_User', include('Add_User.urls')),
    
]
