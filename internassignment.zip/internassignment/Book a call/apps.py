from django.apps import AppConfig


class AddAdvisorConfig(AppConfig):
    name = 'Book a call'
